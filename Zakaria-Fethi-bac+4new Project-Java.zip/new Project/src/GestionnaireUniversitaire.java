import java.util.ArrayList;
import java.util.List;

public class GestionnaireUniversitaire implements GestionnaireUniversitaireI {

	private List<Etudiant> listeEtudiants;
	
	public GestionnaireUniversitaire() {
		listeEtudiants = new ArrayList<Etudiant>();
	}

	public List<Etudiant> getListeEtudiants() {
		return listeEtudiants;
	}

	public void ajouterEtudiant(Etudiant etudiant) {
		listeEtudiants.add(etudiant);
	}

	public void afficherDonnees() {
		System.out.println("Il y " + listeEtudiants.size() + " �tudiant(s) inscrit dans l'universit� : ");
		for (Etudiant etudiant : listeEtudiants) {
			System.out.println(etudiant.getNom() + "\t" + etudiant.getAge() + " ans \t" + etudiant.getfiliere() + "_t"
					+ etudiant.getnote() + "\t" + etudiant.getniveau());
		}
	}
}