public class Personnel {
    protected String nom;
    protected String prenom;
    protected String dateNaissance;
	private String role;
	

public Personnel(String nom, String prenom, String dateNaissance,String role) {
this.nom = nom;
this.prenom = prenom;
this.dateNaissance = dateNaissance;
    }


    // Getters et Setters

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    
    public String getrole() {
        return role;
    }

    public void setrole(String role) {
        this.role = role;
    }

    public String getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(String dateNaissance) {
        this.dateNaissance = dateNaissance;
    }
}