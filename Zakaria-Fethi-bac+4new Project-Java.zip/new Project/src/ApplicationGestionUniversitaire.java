import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ApplicationGestionUniversitaire {

	public static void main(String[] args) {
		System.out.println("Bienvenue dans l'application de gestion universitaire!");

		// Création de l'objet de gestion des données universitaires
		GestionnaireUniversitaire gestionnaire = new GestionnaireUniversitaire();
		importerDonnes(gestionnaire);

		// Boucle principale de l'application
		boolean quitter = false;
		Scanner scanner = new Scanner(System.in);

		while (!quitter) {
			afficherMenu();

			// Lecture de la commande de l'utilisateur
			String commande = scanner.nextLine();

			switch (commande) {
			case "1":
				gestionnaire.afficherDonnees();
				break;
			case "2":
				saisirDonnees(scanner, gestionnaire);
				break;
			case "3":
				sauvegarderDonnees(gestionnaire);
				break;
			case "4":
				quitter = true;
				System.exit(0);
			default:
				System.out.println("Commande invalide!");
				break;
			}
		}
		// Fermeture du scanner
		scanner.close();
	}

	private static void afficherMenu() {
		System.out.println("============== MENU ==============");
		System.out.println("1. Afficher les données");
		System.out.println("2. Saisir des données");
		System.out.println("3. Sauvegarder les données");
		System.out.println("4. Quitter l'application");
		System.out.println("==================================");
		System.out.print("Veuillez entrer votre commande : ");
	}

	private static void saisirDonnees(Scanner scanner, GestionnaireUniversitaire gestionnaire) {

		System.out.print("Entrez le nom de l'étudiant : ");
		String nom = scanner.nextLine();

		System.out.print("Entrez la filière de l'étudiant : ");
		String filiere = scanner.nextLine();

		boolean valeurFausse = true;
		int age = 0;
		while (valeurFausse) {
			try {
				System.out.print("Entrez l'âge de l'étudiant : ");
				age = Integer.parseInt(scanner.nextLine());
				valeurFausse = false;
			} catch (NumberFormatException e) {
				System.out.println("Veuillez entrer une valeur valide ! ");
			}
		}

		System.out.print("Entrez le niveau de l'�tudiant : ");
		String niveau = scanner.nextLine();

		valeurFausse = true;
		int note = 0;
		while (valeurFausse) {
			try {
				System.out.print("Entrez la note de l'étudiant : ");
				note = Integer.parseInt(scanner.nextLine());
				valeurFausse = false;

			} catch (Exception e) {
				System.out.println("Veuillez entrer une valeur valide ! ");
			}
		}

		// Création d'un nouvel étudiant
		Etudiant etudiant = new Etudiant(nom, age, filiere, note, niveau);
		gestionnaire.ajouterEtudiant(etudiant);

		System.out.println("Données saisies avec succès !");
	}

	private static void sauvegarderDonnees(GestionnaireUniversitaire gestionnaire) {
		String fichier = "donnees.txt";
		String path = System.getProperty("user.dir") + "/" + fichier;
		System.out.println(path);
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
			for (Etudiant etudiant : gestionnaire.getListeEtudiants()) {
				writer.write(etudiant.getNom() + "," + etudiant.getAge() +","+ etudiant.getfiliere() +","+ etudiant.getnote()
						+ ","+etudiant.getniveau());
				writer.newLine();
			}
			System.out.println("Données sauvegardées avec succès !");
		} catch (IOException e) {
			System.out.println("Erreur lors de la sauvegarde des données : " + e.getMessage());
		}
	}

	private static void importerDonnes(GestionnaireUniversitaire gestionnaire) {
		String fichier = "donnees.txt";
		String path = System.getProperty("user.dir") + "/" + fichier;
		try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] etudiantData = line.split(",");

				if (etudiantData.length == 5) {
					String nom = etudiantData[0];
					int age = Integer.parseInt(etudiantData[1]);
					String filiere = etudiantData[2];
					int note = Integer.parseInt(etudiantData[3]);
					String niveau = etudiantData[4];
					Etudiant etudiant = new Etudiant(nom, age, filiere, note, niveau);
					gestionnaire.ajouterEtudiant(etudiant);
				}
			}
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		} 
	}
}