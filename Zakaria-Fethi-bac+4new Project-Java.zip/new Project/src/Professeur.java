public class Professeur extends Personnel {

	private String specialite;

	public Professeur(String nom, String prenom, String role, String dateNaissance, String specialite) {

		super(nom, prenom, role, dateNaissance);

		this.specialite = specialite;
	}

	// Getters et Setters

	public String getNom() {
		return getNom();
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getSpecialite() {
		return specialite;
	}

	public void setSpecialite(String specialite) {
		this.specialite = specialite;
	}
}