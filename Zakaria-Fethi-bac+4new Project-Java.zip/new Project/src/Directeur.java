
// Classe Directeur
public class Directeur {
    private String nom;
    private String departement;

    public Directeur(String nom, String departement) {
        this.nom = nom;
        this.departement = departement;
    }

    // Getters et Setters

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }
}