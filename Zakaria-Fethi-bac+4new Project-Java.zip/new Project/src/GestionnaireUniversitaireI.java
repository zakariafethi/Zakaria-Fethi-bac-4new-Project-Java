
public interface GestionnaireUniversitaireI {

	public void ajouterEtudiant(Etudiant etudiant);
	
	public void afficherDonnees();
}
