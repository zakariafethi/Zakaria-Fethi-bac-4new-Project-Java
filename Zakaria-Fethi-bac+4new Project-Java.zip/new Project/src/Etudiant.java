// Classe Étudiant
public class Etudiant {
	private String nom;
	private String filiere;
	private int age;
	private int note;
	private String niveau;

	public Etudiant(String nom, int age, String filiere, int note, String niveau) {
		this.nom = nom;
		this.age = age;
		this.filiere = filiere;
		this.note = note;
		this.niveau = niveau;

	}

	// Getters et Setters

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getfiliere() {
		return filiere;
	}

	public void setfiliere(String filiere) {
		this.filiere = filiere;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getnote() {
		return note;
	}

	public void setnote(int note) {
		this.note = note;
	}

	public String getniveau() {
		return niveau;
	}

	public void setniveau(String niveau) {
		this.niveau = niveau;
	}
}